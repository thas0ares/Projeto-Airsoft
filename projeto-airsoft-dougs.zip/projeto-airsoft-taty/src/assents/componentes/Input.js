import React from 'react';
import { StyleSheet, View, Text } from 'react-native';

const Input = ({ children, text }) => {
  return <Text style={styles.text}>{(children, text)}</Text>;
};

const styles = StyleSheet.create({
  text: {
    flex: 1,
    backgroundColor: '#f0870c',
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default Input;
